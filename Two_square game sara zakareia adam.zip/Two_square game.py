i=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
print("Welcome to Two _ squares game")
player1=str(input("player's 1 name is : "))
player2=str(input("player's 2 name is : "))
print("Hint : you have to choose two numbers, the two numbers must place a rectangle and if you failed twice we will move to the other player, Good luck :) ")
print(player1," your turn ")
print("=====================")
print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
print('|','',i[8],'|',i[9],'|',i[10],'|',i[11],'|')
print('|',i[12],'|',i[13],'|',i[14],'|',i[15],'|')
print("=====================")
x=int(input('the first number : '))
y=int(input('the second number : '))
if (y==x+1) or (y==x-1) or (y==x+4) or (y==x-4):
    i[x-1]='X'
    i[y-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
    print('|',  i[12]  ,'|',i[13],'|',i[14]  ,'|',i[15]  ,'|')
    print("=====================")
    print(player2," your turn ")
else:
    print("Sorry it's not allowed , please choose depending on the laws , try again ")
    x=int(input('the first number :  '))
    y=int(input(' the second number : '))
    if (y==x+1) or (y==x-1) or (y==x+4) or (y==x-4):
        i[x-1]='X'
        i[y-1]='X'
        print("=====================")
        print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
        print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
        print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
        print('|',  i[12]  ,'|',i[13],'|',i[14]  ,'|',i[15]  ,'|')
        print("=====================")
        print(player2," your turn ")
x1=int(input('the first number : '))
y1=int(input('the second number : '))
if (y1==x1+1) or (y1==x1-1) or (y1==x1+4) or (y1==x1-4):
    i[x1-1]='X'
    i[y1-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|', i[9],'|',    i[10],'|',  i[11],'|')
    print('|',  i[12],'|',i[13] ,'|' ,i[14] , '|',  i[15],'|')
    print("=====================") 
    print(player1,'your turn')
else:
    print("Sorry it's not allowed , please choose depending on the laws , Try again ")
    x1=int(input('the first number : '))
    y1=int(input('the second number : '))
    if (y1==x1+1) or (y1==x1-1) or (y1==x1+4) or (y1==x1-4):
        i[x1-1]='X'
        i[y1-1]='X'
        print("=====================")
        print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
        print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
        print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
        print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
        print("=====================") 
        print(player1,'your turn')
x2=int(input('the first number : '))
y2=int(input('the second number : '))
if (y2==x2+1) or (y2==x2-1) or (y2==x2+4) or (y2==x2-4):
    i[x2-1]='X'
    i[y2-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
    print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
    print("=====================")  
    print(player2,'your turn')
else:
    print("Sorry it's not allowed , please choose depending on the laws ")
    x2=int(input('the first number : '))
    y2=int(input('the second number : '))
    if (y2==x2+1) or (y2==x2-1) or (y2==x2+4) or (y2==x2-4):
        i[x2-1]='X'
        i[y2-1]='X'
        print("=====================")
        print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
        print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
        print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
        print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
        print("=====================")  
        print(player2,'your turn')
x3=int(input('the first number : '))     #you have to choose the numbers that not choosen before 
y3=int(input('the second number : '))    #you have to choose the numbers that not choosen before
if (y3==x3+1) or (y3==x3-1) or (y3==x3+4) or (y3==x3-4):
    i[x3-1]='X'
    i[y3-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
    print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
    print("=====================")   
    print(player1,'your turn')
else:
    print("Sorry it's not allowed , please choose depending on the laws ")
    x3=int(input('the first number : '))
    y3=int(input('the second number : '))
    if (y3==x3+1) or (y3==x3-1) or (y3==x3+4) or (y3==x3-4):
        i[x3-1]='X'
        i[y3-1]='X'
        print("=====================")
        print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
        print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
        print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
        print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
        print("=====================")  
        print(player1,'your turn')
x4=int(input('the first number : '))     #you have to choose the numbers that not choosen before
y4=int(input('the second number : '))    #you have to choose the numbers that not choosen before
if (y4==x4+1) or (y4==x4-1) or (y4==x4+4) or (y4==x4-4):
    i[x4-1]='X'
    i[y4-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
    print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
    print("=====================") 
    print(player2,'your turn')
else:
    print("Sorry it's not allowed , please choose depending on the laws ")
    x4=int(input('the first number : '))
    y4=int(input('the second number : '))
    if (y4==x4+1) or (y4==x4-1) or (y4==x4+4) or (y4==x4-4):
        i[x4-1]='X'
        i[y4-1]='X'
        print("=====================")
        print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
        print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
        print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
        print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
        print("=====================") 
        print(player2,'your turn')
x5=int(input('the first number : '))     #you have to choose the numbers that not choosen before
y5=int(input('the second number : '))    #you have to choose the numbers that not choosen before
import sys
if (y5==x5+1) or (y5==x5-1) or (y5==x5+4) or (y5==x5-4):
    i[x5-1]='X'
    i[y5-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
    print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
    print("=====================")
    print(player1,'your turn')
else:
    print("Sorry it's not allowed , please choose depending on the laws ")
    x5=int(input('the first number : '))
    y5=int(input('the second number : '))
    if (y5==x5+1) or (y5==x5-1) or (y5==x5+4) or (y5==x5-4):
        i[x5-1]='X'
        i[y5-1]='X'
        print("=====================")
        print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
        print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
        print('|','',i[8],'|'   ,i[9],'|',i[10]  ,'|',i[11]  ,'|')
        print('|',  i[12],'|'  ,i[13],'|',i[14]  ,'|',i[15]  ,'|')
        print("=====================")  
        print(player1,'your turn')
    else:
        print(player2,'is the looser')
        sys.exit(0)
x6=int(input('the first number : '))    #you have to choose the numbers that not choosen before
y6=int(input('the second number : '))  #you have to choose the numbers that not choosen before 
import sys
if (y6==x6+1) or (y6==x6-1) or (y6==x6+4) or (y6==x6-4):
    i[x6-1]='X'
    i[y6-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|', i[9],  '|',i[10]  ,'|',  i[11],'|')
    print('|',  i[12],'|',i[13] , '|' , i[14],'|',  i[15],'|')
    print("=====================") 
    print(player2,'your turn')  
elif (y6!=x6+1) or (y6!=x6-1) or (y6!=x6+4) or (y6!=x6-4):
    print("Sorry it's not allowed , please choose depending on the laws ")
    x6=int(input('the first number : '))
    y6=int(input('the second number : '))
    import sys
    if (y6==x6+1) or (y6==x6-1) or (y6==x6+4) or (y6==x6-4):
        i[x6-1]='X'
        i[y6-1]='X'
        print("=====================")
        print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
        print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
        print('|','',i[8],'|', i[9],  '|',  i[10],'|',  i[11],'|')
        print('|',  i[12],'|',i[13] , '|' ,i[14] ,'|',  i[15],'|')
        print("=====================") 
        print(player2,'your turn')
    else:
        print(player2,'is the winner')
        sys.exit(0)
else:
    print(palyer2,'is the winner')
    sys.exit(0)
x7=int(input('the first number : '))      #you have to choose the numbers that not choosen before
y7=int(input('the second number : '))     #you have to choose the numbers that not choosen before
if (y7==x7+1) or (y7==x7-1) or (y7==x7+4) or (y7==x7-4):
    i[x7-1]='X'
    i[y7-1]='X'
    print("=====================")
    print('|','',i[0],'|','',i[1],'|','',i[2],'|','',i[3],'|')
    print('|','',i[4],'|','',i[5],'|','',i[6],'|','',i[7],'|')
    print('|','',i[8],'|', i[9],  '|',  i[10],'|',  i[11],'|')
    print('|',  i[12],'|',i[13] , '|' ,i[14] ,'|',  i[15],'|')
    print("=====================") 
    print('no one wins')
else:
    print(player1,'is the winner')



     

    
    

    

    







           

       

